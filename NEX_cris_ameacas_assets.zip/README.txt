Pacote organizado a partir de C.R.I.S. - Ordem Paranormal.zip
Total de retratos de ameaças: 49
Inclui apenas retratos profile das ameaças do Livro Básico; banners de elementos foram ignorados.
