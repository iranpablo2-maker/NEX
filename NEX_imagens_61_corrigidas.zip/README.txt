Imagens extraídas dos PDFs enviados. Para integrar ao NEX, envie a pasta assets/ameacas ao repositório GitHub, preservando a estrutura.
ATENÇÃO: verifique o enquadramento e o nome da criatura nas imagens. O pacote foi extraído automaticamente das páginas.
