Pacote de 12 retratos de Sobrevivendo ao Horror enviado pelo usuário.
Mapeamento atual (pode ser ajustado depois se o usuário quiser trocar algum retrato):
- Mescla
- Sepultado
- Espectro Inesquecido
- Derretido
- O Uivar
- Melancolia
- Quibungo
- Profundo
- Memento Mori
- Rascunho
- Medusa
- Amigo Imaginário
