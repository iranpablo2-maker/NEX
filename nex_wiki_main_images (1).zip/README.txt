Pacote com imagens principais da Wiki para ameaças do NEX.
Somente as novas imagens foram mantidas como principais, sem reservas.
Total de imagens selecionadas: 44
