window.NEX_THREAT_IMAGES = {
  "Livro Básico::Aberração de Carne": {
    "path": "./assets/ameacas/livro-basico/aberracao-de-carne.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Sangue/Arte_Aberração_de_Carne_no_Livro_de_Regras.png"
  },
  "Livro Básico::Aniquilação": {
    "path": "./assets/ameacas/livro-basico/aniquilacao.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Sangue/Aniquilação_no_Livro_de_Regras.png"
  },
  "Livro Básico::Dama de Sangue": {
    "path": "./assets/ameacas/livro-basico/dama-de-sangue.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Sangue/Arte_da_Dama_de_Sangue_em_Os_Espinhos_da_Aurora_Escarlate.png"
  },
  "Livro Básico::Enpap-X": {
    "path": "./assets/ameacas/livro-basico/enpap-x.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Sangue/Miniatura_Enpap-X_em_Desconjura3Fo.png"
  },
  "Livro Básico::Kerberos": {
    "path": "./assets/ameacas/livro-basico/kerberos.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Sangue/Arte_do_Kerberos_em_Livro_de_Regras.png"
  },
  "Livro Básico::Minotauro": {
    "path": "./assets/ameacas/livro-basico/minotauro.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Sangue/Miniatura_Minotauro_em_Calamidade.png"
  },
  "Livro Básico::Mulher Afogada": {
    "path": "./assets/ameacas/livro-basico/mulher-afogada.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Sangue/Miniatura_Mulher_Afogada_em_Desconjura3Fo.png"
  },
  "Livro Básico::Zumbi de Sangue": {
    "path": "./assets/ameacas/livro-basico/zumbi-de-sangue.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Sangue/Miniatura_Zumbi_de_Sangue_em_Desconjura3Fo.png"
  },
  "Livro Básico::Zumbi de Sangue Bestial": {
    "path": "./assets/ameacas/livro-basico/zumbi-de-sangue-bestial.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Sangue/Bestial_em_Desconjuração.png"
  },
  "Livro Básico::O Carente": {
    "path": "./assets/ameacas/livro-basico/o-carente.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Sangue/Miniatura_Carente_em_Calamidade.png"
  },
  "Livro Básico::O Diabo": {
    "path": "./assets/ameacas/livro-basico/o-diabo.png",
    "source_file": "Criaturas Tokens Wiki/Entidades/Miniatura_O_Diabo_em_Calamidade.png"
  },
  "Livro Básico::Aracnasita": {
    "path": "./assets/ameacas/livro-basico/aracnasita.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Morte/Arte_da_Aracnasita_no_Livro_de_Regras.png"
  },
  "Livro Básico::Enraizado": {
    "path": "./assets/ameacas/livro-basico/enraizado.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Morte/Arte_do_Enraizado_no_livro_de_regras.png"
  },
  "Livro Básico::Escutado": {
    "path": "./assets/ameacas/livro-basico/escutado.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Morte/Miniatura_Escutado_em_Desconjura3Fo.png"
  },
  "Livro Básico::Carniçal": {
    "path": "./assets/ameacas/livro-basico/carnical.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Morte/Arte_do_Carniçal_Preto_da_Morte_no_livro_de_regras.png"
  },
  "Livro Básico::Ceifador Espiral": {
    "path": "./assets/ameacas/livro-basico/ceifador-espiral.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Morte/Arte_de_Ceifador_Espiral_em_Livro_de_Regras.png"
  },
  "Livro Básico::Esqueleto de Lodo": {
    "path": "./assets/ameacas/livro-basico/esqueleto-de-lodo.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Morte/Arte_do_Esqueleto_de_Lodo_no_livro_de_regras.png"
  },
  "Livro Básico::A Marionete": {
    "path": "./assets/ameacas/livro-basico/a-marionete.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Morte/Miniatura_da_Marionete_em_Calamidade.png"
  },
  "Livro Básico::Múmia Xipófaga": {
    "path": "./assets/ameacas/livro-basico/mumia-xipofaga.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Morte/Miniatura_M_3Fmia_em_Calamidade.png"
  },
  "Livro Básico::Nidere": {
    "path": "./assets/ameacas/livro-basico/nidere.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Morte/Nidere_no_Livro_de_Regras.png"
  },
  "Livro Básico::Sempiternal": {
    "path": "./assets/ameacas/livro-basico/sempiternal.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Morte/Arte_do_Sempiternal_no_livro_de_regras.png"
  },
  "Livro Básico::Succ": {
    "path": "./assets/ameacas/livro-basico/succ.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Morte/Arte_do_Succ_no_Livro_de_Regras.png"
  },
  "Livro Básico::O Deus da Morte": {
    "path": "./assets/ameacas/livro-basico/o-deus-da-morte.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Morte/Arte_do_Deus_da_Morte_no_livro_de_regras.png"
  },
  "Livro Básico::O Espreitador": {
    "path": "./assets/ameacas/livro-basico/o-espreitador.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Conhecimento/Miniatura_de_Espreitador.png"
  },
  "Livro Básico::Estrangeiro": {
    "path": "./assets/ameacas/livro-basico/estrangeiro.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Conhecimento/Arte_do_Estrangeiro_em_Livro_de_Regras.png"
  },
  "Livro Básico::Lembrado": {
    "path": "./assets/ameacas/livro-basico/lembrado.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Conhecimento/Arte_do_Lembrado_no_Livro_de_Regras.png"
  },
  "Livro Básico::Parasita de Culpa": {
    "path": "./assets/ameacas/livro-basico/parasita-de-culpa.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Conhecimento/Arte_do_Parasita_de_Culpa_no_Livro_de_Regras.png"
  },
  "Livro Básico::Rastejador Sombrio": {
    "path": "./assets/ameacas/livro-basico/rastejador-sombrio.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Conhecimento/Arte_de_Rastejador_Sombrio_em_Livro_de_Regras.png"
  },
  "Livro Básico::Silhueta": {
    "path": "./assets/ameacas/livro-basico/silhueta.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Conhecimento/Arte_de_Silhueta_em_Livro_de_Regras.png"
  },
  "Livro Básico::Ocioso": {
    "path": "./assets/ameacas/livro-basico/ocioso.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Conhecimento/Arte_de_Ocioso_em_Livro_de_Regras.png"
  },
  "Livro Básico::Anárquico": {
    "path": "./assets/ameacas/livro-basico/anarquico.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Energia/Arte_do_Anarquico_no_livro_de_regras.png"
  },
  "Livro Básico::Anárquico Descontrolado": {
    "path": "./assets/ameacas/livro-basico/anarquico-descontrolado.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Energia/Arte_do_Anárquico_Descontrolado_no_livro_de_regras.png"
  },
  "Livro Básico::Anomalia": {
    "path": "./assets/ameacas/livro-basico/anomalia.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Energia/Arte_de_Anomalia_em_Livro_de_Regras.png"
  },
  "Livro Básico::Anomiático": {
    "path": "./assets/ameacas/livro-basico/anomiatico.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Energia/Arte_do_Anormiático_no_livro_de_regras.png"
  },
  "Livro Básico::Ciborgue": {
    "path": "./assets/ameacas/livro-basico/ciborgue.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Energia/Arte_do_Ciborgue_no_livro_de_regras.png"
  },
  "Livro Básico::Infecticídio": {
    "path": "./assets/ameacas/livro-basico/infecticidio.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Energia/Arte_de_Infecticidio_em_Livro_de_Regras.png"
  },
  "Livro Básico::Perturbado de Energia": {
    "path": "./assets/ameacas/livro-basico/perturbado-de-energia.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Energia/Miniatura_Perturbado_de_Energia_azul_em_Desconjura3Fo.png"
  },
  "Livro Básico::Sukkalgir": {
    "path": "./assets/ameacas/livro-basico/sukkalgir.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Energia/Miniatura_Sukkalgir_em_Desconjura3Fo.png"
  },
  "Livro Básico::Telopsia": {
    "path": "./assets/ameacas/livro-basico/telopsia.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Energia/Telopsia.png"
  },
  "Livro Básico::Tempestuoso": {
    "path": "./assets/ameacas/livro-basico/tempestuoso.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Energia/Arte_de_Tempestuoso_em_Livro_de_Regras.png"
  },
  "Livro Básico::Viajante": {
    "path": "./assets/ameacas/livro-basico/viajante.png",
    "source_file": "Criaturas Tokens Wiki/Criaturas de Energia/Miniatura_Viajante_em_Desconjura3Fo.png"
  },
  "Livro Básico::O Anfitrião": {
    "path": "./assets/ameacas/livro-basico/o-anfitriao.png",
    "source_file": "Criaturas Tokens Wiki/Entidades/Miniatura_O_Anfitri_3Fo_em_Calamidade.png"
  },
  "Livro Básico::Degolificada": {
    "path": "./assets/ameacas/livro-basico/degolificada.png",
    "source_file": "Criaturas Tokens Wiki/Degolificada/Miniatura_Degolificada_em_Desconjura3Fo.png"
  },
  "Sobrevivendo ao Horror::Amigo Imaginário": {
    "path": "./assets/ameacas/sobrevivendo-ao-horror/amigo-imaginario.png",
    "source_file": "Criaturas Tokens Wiki/OSNI/Miniatura_de_Amigo_Imaginário.png"
  }
};
